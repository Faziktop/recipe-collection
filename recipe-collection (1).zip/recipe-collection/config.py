import os

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    # Security: Read secret key from environment or fallback to robust development default
    SECRET_KEY = os.environ.get('SECRET_KEY', 'recipe-hub-super-secret-key-prod-secure-2026')

    # Database: SQLite in instance folder by default, configurable for PostgreSQL/MySQL
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        f"sqlite:///{os.path.join(basedir, 'instance', 'recipes.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
    }

    # File uploads & image optimization
    UPLOAD_FOLDER = os.path.join(basedir, 'static', 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload size
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    IMAGE_MAX_DIMENSION = (1200, 900)
    IMAGE_QUALITY = 82

    # Pagination & Caching
    RECIPES_PER_PAGE = int(os.environ.get('RECIPES_PER_PAGE', 9))
    CACHE_TTL_SECONDS = int(os.environ.get('CACHE_TTL_SECONDS', 120))

    # ==================== 3 EXTERNAL INTEGRATIONS (Educational + Production) ====================
    # 1. Google OAuth 2.0 Integration
    GOOGLE_CLIENT_ID = os.environ.get('GOOGLE_CLIENT_ID', '')
    GOOGLE_CLIENT_SECRET = os.environ.get('GOOGLE_CLIENT_SECRET', '')
    GOOGLE_AUTH_URI = 'https://accounts.google.com/o/oauth2/v2/auth'
    GOOGLE_TOKEN_URI = 'https://oauth2.googleapis.com/token'
    GOOGLE_USERINFO_URI = 'https://www.googleapis.com/oauth2/v3/userinfo'

    # 2. Telegram Bot API Integration
    TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '')
    TELEGRAM_DEFAULT_CHAT_ID = os.environ.get('TELEGRAM_DEFAULT_CHAT_ID', '104928374')
    TELEGRAM_BOT_USERNAME = os.environ.get('TELEGRAM_BOT_USERNAME', 'RecipeCollectionEduBot')

    # 3. Payment System Integration (YooKassa / CloudPay Sandbox)
    PAYMENT_SHOP_ID = os.environ.get('PAYMENT_SHOP_ID', 'EDU-SHOP-98412')
    PAYMENT_SECRET_KEY = os.environ.get('PAYMENT_SECRET_KEY', 'test_secret_yookassa_edu_key_2026')
    PRO_SUBSCRIPTION_PRICE = 299  # RUB

    # Culinary taxonomies
    CATEGORIES = [
        "Завтраки",
        "Основные блюда",
        "Супы",
        "Салаты",
        "Десерты и выпечка",
        "Закуски",
        "Напитки",
        "Соусы и маринады"
    ]

    CUISINES = [
        "Итальянская",
        "Русская",
        "Грузинская",
        "Французская",
        "Паназиатская",
        "Японская",
        "Мексиканская",
        "Средиземноморская",
        "Американская",
        "Ближневосточная",
        "Другая"
    ]

    DIFFICULTIES = [
        "Легко",
        "Средне",
        "Сложно"
    ]
