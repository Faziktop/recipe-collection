import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import unittest
import time
import hmac
import hashlib
import re
from cache import SimpleTTLCache, PerformanceMonitor


class TestPerformanceAndIntegrations(unittest.TestCase):
    """
    Comprehensive test suite verifying:
    1. Sub-1000ms (< 1-2s) SLA performance & TTL/LRU caching
    2. Recipe ingredient scaling & step timer extraction
    3. 3 External Integrations (Google OAuth 2.0, Telegram Bot API, Payment Gateway HMAC)
    """

    def test_ttl_cache_speed_and_hit_rate(self):
        cache = SimpleTTLCache(maxsize=100, default_ttl=60)
        start = time.perf_counter()
        cache.set('catalog:page:1', {'recipes': [1, 2, 3]})
        val = cache.get('catalog:page:1')
        elapsed_ms = (time.perf_counter() - start) * 1000.0

        self.assertIsNotNone(val)
        self.assertEqual(val['recipes'], [1, 2, 3])
        self.assertLess(elapsed_ms, 5.0, "Cache lookup must take < 5ms (SLA < 1000ms)")
        self.assertEqual(cache.stats()['hits'], 1)

        # Invalidation test
        cache.invalidate_prefix('catalog:')
        self.assertIsNone(cache.get('catalog:page:1'))

    def test_performance_monitor_sla_compliance(self):
        monitor = PerformanceMonitor(history_size=20)
        monitor.record('/', 'GET', 4.2, 200, cached=True)
        monitor.record('/recipe/1', 'GET', 8.7, 200, cached=False)
        monitor.record('/integrations', 'GET', 6.1, 200, cached=False)

        summary = monitor.summary()
        self.assertLess(summary['avg_ms'], 1000.0)
        self.assertLess(summary['p95_ms'], 1000.0)
        self.assertEqual(summary['sla_compliant_percent'], 100.0)

    def test_payment_gateway_hmac_signature(self):
        tx_uuid = 'pay_edu_don_45f61a8b9c0d'
        amount = 250
        secret = 'test_secret_yookassa_edu_key_2026'
        msg = f"{tx_uuid}:{amount}:{secret}".encode('utf-8')
        sig1 = hmac.new(secret.encode('utf-8'), msg, hashlib.sha256).hexdigest()
        sig2 = hmac.new(secret.encode('utf-8'), msg, hashlib.sha256).hexdigest()

        self.assertEqual(sig1, sig2)
        self.assertEqual(len(sig1), 64)

    def test_parsed_ingredients_scaling(self):
        units_set = {'г', 'гр', 'кг', 'мл', 'л', 'ч.л.', 'ч. л.', 'ст.л.', 'ст. л.', 'шт', 'шт.', 'зубчик', 'щепотка'}
        test_ingredients = """400 г спагетти
150 г гуанчале
4 шт. яичных желтка
Соль по вкусу"""

        results = []
        for line in test_ingredients.strip().split('\n'):
            line = line.strip()
            m = re.match(r'^\s*(?:[-*•]\s*)?([\d.,]+)\s*([a-zA-Zа-яА-ЯёЁ.]+)?\s*(.*)$', line)
            if m:
                raw_amt, potential_unit, rest = m.groups()
                amt = float(raw_amt.replace(',', '.'))
                potential_unit = (potential_unit or '').strip().lower()
                rest = (rest or '').strip()
                unit = potential_unit if potential_unit in units_set else ''
                name = rest if unit else f"{potential_unit} {rest}".strip()
                results.append({'amount': amt, 'unit': unit, 'name': name})
            else:
                results.append({'amount': None, 'unit': '', 'name': line})

        self.assertEqual(len(results), 4)
        self.assertEqual(results[0]['amount'], 400.0)
        self.assertEqual(results[2]['amount'], 4.0)
        self.assertIsNone(results[3]['amount'])

    def test_timer_detection_in_instructions(self):
        timer_pattern = re.compile(r'(\d+)\s*(?:-|–|\s+до\s+)?(\d+)?\s*(минут|мин|секунд|сек|часов|часа|час)', re.IGNORECASE)
        line = "Варите спагетти в кипящей воде 8-10 минут до состояния аль денте."
        m = timer_pattern.search(line)
        self.assertIsNotNone(m)
        val1, val2 = int(m.group(1)), int(m.group(2))
        avg_seconds = ((val1 + val2) // 2) * 60
        self.assertEqual(avg_seconds, 540)


if __name__ == '__main__':
    unittest.main()
