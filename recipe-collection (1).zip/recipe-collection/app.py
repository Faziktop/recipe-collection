from flask import (
    Flask, render_template, request, redirect, url_for, flash,
    abort, send_from_directory, jsonify, session, g
)
from flask_login import (
    LoginManager, login_user, login_required, logout_user, current_user
)
from sqlalchemy.orm import joinedload, selectinload
from werkzeug.utils import secure_filename
from datetime import datetime
import os
import uuid
import secrets
from functools import wraps

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

from config import Config
from models import db, User, Recipe, Review, Favorite, PaymentTransaction, TelegramLog
from cache import app_cache, perf_monitor, cached_call, register_performance_middleware
from integrations import GoogleOAuthIntegration, TelegramBotIntegration, PaymentGatewayIntegration


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Ensure upload folder and instance folder exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    instance_dir = os.path.join(app.root_path, 'instance')
    os.makedirs(instance_dir, exist_ok=True)

    # Initialize database & login manager
    db.init_app(app)

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    login_manager.login_message = 'Пожалуйста, войдите в систему для доступа к этой странице.'
    login_manager.login_message_category = 'warning'

    # Register high-speed performance middleware (Gzip + Cache-Control + SLA Timing)
    register_performance_middleware(app)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # Helper functions
    def allowed_file(filename):
        return '.' in filename and \
            filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

    def save_optimized_image(file_storage):
        """Saves and automatically compresses/resizes uploaded images for fast (<1s) page loads."""
        safe_name = secure_filename(file_storage.filename)
        ext = safe_name.rsplit('.', 1)[1].lower() if '.' in safe_name else 'jpg'
        unique_name = f"{uuid.uuid4().hex}.{ext}"
        dest_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)

        if PIL_AVAILABLE and ext in {'jpg', 'jpeg', 'png', 'webp'}:
            try:
                img = Image.open(file_storage)
                img.thumbnail(app.config.get('IMAGE_MAX_DIMENSION', (1200, 900)), Image.Resampling.LANCZOS)
                if ext in {'jpg', 'jpeg'} and img.mode in ('RGBA', 'P'):
                    img = img.convert('RGB')
                img.save(dest_path, optimize=True, quality=app.config.get('IMAGE_QUALITY', 82))
                return unique_name
            except Exception:
                file_storage.seek(0)

        file_storage.save(dest_path)
        return unique_name

    def admin_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or not current_user.is_admin:
                abort(403)
            return f(*args, **kwargs)
        return decorated_function

    @cached_call(prefix='global_counts', ttl=60)
    def get_cached_global_counts():
        return {
            'recipes_count': Recipe.query.count(),
            'users_count': User.query.count(),
            'reviews_count': Review.query.count()
        }

    # Context Processors for Templates
    @app.context_processor
    def inject_global_data():
        user_favs_count = 0
        if current_user.is_authenticated:
            user_favs_count = len(current_user.favorites)
        counts = get_cached_global_counts()
        return {
            'app_categories': app.config['CATEGORIES'],
            'app_cuisines': app.config['CUISINES'],
            'app_difficulties': app.config['DIFFICULTIES'],
            'user_favorites_count': user_favs_count,
            'global_recipes_count': counts['recipes_count'],
            'pro_price': app.config.get('PRO_SUBSCRIPTION_PRICE', 299),
            'current_year': datetime.utcnow().year
        }

    # Static uploads handler
    @app.route('/uploads/<filename>')
    def uploaded_file(filename):
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

    # ==================== MAIN CATALOG & SEARCH (OPTIMIZED) ====================
    @app.route('/')
    def index():
        search_query = request.args.get('q', '').strip()
        cuisine = request.args.get('cuisine', '').strip()
        category = request.args.get('category', '').strip()
        difficulty = request.args.get('difficulty', '').strip()
        max_time = request.args.get('max_time', type=int)
        sort_by = request.args.get('sort', 'newest')
        page = request.args.get('page', 1, type=int)

        # Eager load author, reviews, and favorites in a single batch to prevent N+1 queries
        query = Recipe.query.options(
            joinedload(Recipe.author),
            selectinload(Recipe.reviews),
            selectinload(Recipe.favorites)
        )

        if search_query:
            search_pattern = f"%{search_query}%"
            query = query.filter(
                (Recipe.title.ilike(search_pattern)) |
                (Recipe.description.ilike(search_pattern)) |
                (Recipe.cuisine.ilike(search_pattern)) |
                (Recipe.ingredients.ilike(search_pattern))
            )

        if cuisine:
            query = query.filter(Recipe.cuisine == cuisine)
        if category and category != 'Все':
            query = query.filter(Recipe.category == category)
        if difficulty:
            query = query.filter(Recipe.difficulty == difficulty)
        if max_time:
            query = query.filter((Recipe.prep_time + Recipe.cook_time) <= max_time)

        if sort_by == 'popular':
            query = query.order_by(Recipe.views_count.desc(), Recipe.created_at.desc())
        elif sort_by == 'fastest':
            query = query.order_by((Recipe.prep_time + Recipe.cook_time).asc())
        elif sort_by == 'oldest':
            query = query.order_by(Recipe.created_at.asc())
        else:
            query = query.order_by(Recipe.created_at.desc())

        pagination = query.paginate(page=page, per_page=app.config['RECIPES_PER_PAGE'], error_out=False)
        recipes = pagination.items
        total_recipes_count = get_cached_global_counts()['recipes_count']

        return render_template(
            'index.html',
            recipes=recipes,
            pagination=pagination,
            search_query=search_query,
            selected_cuisine=cuisine,
            selected_category=category,
            selected_difficulty=difficulty,
            selected_max_time=max_time,
            selected_sort=sort_by,
            total_recipes_count=total_recipes_count
        )

    # ==================== RECIPE DETAILS & COOKING MODE ====================
    @app.route('/recipe/<int:recipe_id>')
    def recipe_detail(recipe_id):
        recipe = Recipe.query.options(
            joinedload(Recipe.author),
            selectinload(Recipe.reviews).joinedload(Review.author),
            selectinload(Recipe.favorites)
        ).get_or_404(recipe_id)

        recipe.views_count += 1
        db.session.commit()

        user_review = None
        is_favorite = False
        if current_user.is_authenticated:
            user_review = next((r for r in recipe.reviews if r.user_id == current_user.id), None)
            is_favorite = any(f.user_id == current_user.id for f in recipe.favorites)

        related_recipes = Recipe.query.options(
            joinedload(Recipe.author),
            selectinload(Recipe.reviews)
        ).filter(
            (Recipe.cuisine == recipe.cuisine) | (Recipe.category == recipe.category),
            Recipe.id != recipe.id
        ).order_by(Recipe.views_count.desc()).limit(3).all()

        recent_donations = PaymentTransaction.query.filter_by(
            recipe_id=recipe.id, status='succeeded', payment_type='donation'
        ).order_by(PaymentTransaction.paid_at.desc()).limit(5).all()

        return render_template(
            'recipe_detail.html',
            recipe=recipe,
            ingredients=recipe.parsed_ingredients(),
            instructions=recipe.parsed_instructions(),
            images=recipe.get_images(),
            user_review=user_review,
            is_favorite=is_favorite,
            related_recipes=related_recipes,
            recent_donations=recent_donations
        )

    @app.route('/recipe/<int:recipe_id>/cook')
    def cooking_mode(recipe_id):
        recipe = Recipe.query.get_or_404(recipe_id)
        return render_template(
            'cooking_mode.html',
            recipe=recipe,
            instructions=recipe.parsed_instructions(),
            ingredients=recipe.parsed_ingredients()
        )

    # ==================== RECIPE CRUD ====================
    @app.route('/recipe/add', methods=['GET', 'POST'])
    @login_required
    def add_recipe():
        if request.method == 'POST':
            title = request.form.get('title', '').strip()
            cuisine = request.form.get('cuisine', '').strip()
            category = request.form.get('category', 'Основные блюда').strip()
            difficulty = request.form.get('difficulty', 'Средне').strip()
            prep_time = request.form.get('prep_time', type=int) or 15
            cook_time = request.form.get('cook_time', type=int) or 30
            servings = request.form.get('servings', type=int) or 4
            calories = request.form.get('calories', type=int)
            protein = request.form.get('protein', type=float)
            fat = request.form.get('fat', type=float)
            carbs = request.form.get('carbs', type=float)
            dietary = request.form.get('dietary', '').strip()
            description = request.form.get('description', '').strip()
            ingredients = request.form.get('ingredients', '').strip()
            instructions = request.form.get('instructions', '').strip()

            if not title or not cuisine or not description or not ingredients or not instructions:
                flash('Пожалуйста, заполните все обязательные поля!', 'error')
                return render_template('add_recipe.html', form_data=request.form)

            image_paths = []
            if 'images' in request.files:
                files = request.files.getlist('images')
                for file in files:
                    if file and file.filename != '' and allowed_file(file.filename):
                        unique_name = save_optimized_image(file)
                        image_paths.append(unique_name)

            recipe = Recipe(
                title=title,
                cuisine=cuisine,
                category=category,
                difficulty=difficulty,
                prep_time=prep_time,
                cook_time=cook_time,
                servings=servings,
                calories=calories,
                protein=protein,
                fat=fat,
                carbs=carbs,
                dietary=dietary,
                description=description,
                ingredients=ingredients,
                instructions=instructions,
                images=','.join(image_paths),
                user_id=current_user.id
            )

            db.session.add(recipe)
            db.session.commit()
            app_cache.invalidate_prefix('')

            # Optional automatic Telegram notification on new recipe
            if request.form.get('notify_telegram'):
                TelegramBotIntegration.send_recipe_card(
                    recipe,
                    chat_id=current_user.telegram_chat_id or app.config['TELEGRAM_DEFAULT_CHAT_ID']
                )

            flash('Рецепт успешно добавлен в коллекцию!', 'success')
            return redirect(url_for('recipe_detail', recipe_id=recipe.id))

        return render_template('add_recipe.html')

    @app.route('/recipe/<int:recipe_id>/edit', methods=['GET', 'POST'])
    @login_required
    def edit_recipe(recipe_id):
        recipe = Recipe.query.get_or_404(recipe_id)

        if recipe.user_id != current_user.id and not current_user.is_admin:
            abort(403)

        if request.method == 'POST':
            recipe.title = request.form.get('title', '').strip()
            recipe.cuisine = request.form.get('cuisine', '').strip()
            recipe.category = request.form.get('category', 'Основные блюда').strip()
            recipe.difficulty = request.form.get('difficulty', 'Средне').strip()
            recipe.prep_time = request.form.get('prep_time', type=int) or 15
            recipe.cook_time = request.form.get('cook_time', type=int) or 30
            recipe.servings = request.form.get('servings', type=int) or 4
            recipe.calories = request.form.get('calories', type=int)
            recipe.protein = request.form.get('protein', type=float)
            recipe.fat = request.form.get('fat', type=float)
            recipe.carbs = request.form.get('carbs', type=float)
            recipe.dietary = request.form.get('dietary', '').strip()
            recipe.description = request.form.get('description', '').strip()
            recipe.ingredients = request.form.get('ingredients', '').strip()
            recipe.instructions = request.form.get('instructions', '').strip()

            if 'images' in request.files:
                files = request.files.getlist('images')
                existing_images = recipe.get_images()
                new_images = []

                for file in files:
                    if file and file.filename != '' and allowed_file(file.filename):
                        unique_name = save_optimized_image(file)
                        new_images.append(unique_name)

                if new_images:
                    recipe.images = ','.join(existing_images + new_images)

            recipe.updated_at = datetime.utcnow()
            db.session.commit()
            app_cache.invalidate_prefix('')
            flash('Рецепт успешно обновлен!', 'success')
            return redirect(url_for('recipe_detail', recipe_id=recipe.id))

        return render_template('edit_recipe.html', recipe=recipe, images=recipe.get_images())

    @app.route('/recipe/<int:recipe_id>/delete-image/<filename>', methods=['POST'])
    @login_required
    def delete_recipe_image(recipe_id, filename):
        recipe = Recipe.query.get_or_404(recipe_id)

        if recipe.user_id != current_user.id and not current_user.is_admin:
            abort(403)

        images = recipe.get_images()
        if filename in images:
            images.remove(filename)
            recipe.images = ','.join(images)

            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except OSError:
                    pass

            db.session.commit()
            app_cache.invalidate_prefix('')
            flash('Изображение удалено!', 'success')

        return redirect(url_for('edit_recipe', recipe_id=recipe.id))

    @app.route('/recipe/<int:recipe_id>/delete', methods=['POST'])
    @login_required
    def delete_recipe(recipe_id):
        recipe = Recipe.query.get_or_404(recipe_id)

        if recipe.user_id != current_user.id and not current_user.is_admin:
            abort(403)

        for filename in recipe.get_images():
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except OSError:
                    pass

        db.session.delete(recipe)
        db.session.commit()
        app_cache.invalidate_prefix('')
        flash('Рецепт успешно удален!', 'success')

        if request.referrer and 'profile' in request.referrer:
            return redirect(url_for('profile', username=current_user.username))
        return redirect(url_for('index'))

    # ==================== FAVORITES & REVIEWS ====================
    @app.route('/recipe/<int:recipe_id>/favorite', methods=['POST'])
    @login_required
    def toggle_favorite(recipe_id):
        recipe = Recipe.query.get_or_404(recipe_id)
        fav = Favorite.query.filter_by(user_id=current_user.id, recipe_id=recipe.id).first()

        if fav:
            db.session.delete(fav)
            is_fav = False
            msg = 'Рецепт удален из избранного'
        else:
            fav = Favorite(user_id=current_user.id, recipe_id=recipe.id)
            db.session.add(fav)
            is_fav = True
            msg = 'Рецепт добавлен в избранное!'

        db.session.commit()
        app_cache.invalidate_prefix('')

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
            return jsonify({
                'status': 'success',
                'is_favorite': is_fav,
                'count': recipe.favorites_count,
                'message': msg
            })

        flash(msg, 'info')
        return redirect(request.referrer or url_for('recipe_detail', recipe_id=recipe_id))

    @app.route('/recipe/<int:recipe_id>/review', methods=['POST'])
    @login_required
    def add_review(recipe_id):
        recipe = Recipe.query.get_or_404(recipe_id)
        rating = request.form.get('rating', type=int)
        comment = request.form.get('comment', '').strip()

        if not rating or rating < 1 or rating > 5:
            flash('Пожалуйста, выберите оценку от 1 до 5 звезд!', 'error')
            return redirect(url_for('recipe_detail', recipe_id=recipe_id))

        review = Review.query.filter_by(recipe_id=recipe.id, user_id=current_user.id).first()
        if review:
            review.rating = rating
            review.comment = comment
            review.created_at = datetime.utcnow()
            flash('Ваш отзыв обновлен!', 'success')
        else:
            review = Review(
                rating=rating,
                comment=comment,
                recipe_id=recipe.id,
                user_id=current_user.id
            )
            db.session.add(review)
            flash('Спасибо за ваш отзыв!', 'success')

        db.session.commit()
        app_cache.invalidate_prefix('')
        return redirect(url_for('recipe_detail', recipe_id=recipe_id))

    @app.route('/review/<int:review_id>/delete', methods=['POST'])
    @login_required
    def delete_review(review_id):
        review = Review.query.get_or_404(review_id)
        recipe_id = review.recipe_id

        if review.user_id != current_user.id and not current_user.is_admin:
            abort(403)

        db.session.delete(review)
        db.session.commit()
        app_cache.invalidate_prefix('')
        flash('Отзыв удален!', 'success')
        return redirect(url_for('recipe_detail', recipe_id=recipe_id))

    # ==================== USER PROFILE & SHOPPING LIST ====================
    @app.route('/profile')
    @login_required
    def my_profile():
        return redirect(url_for('profile', username=current_user.username))

    @app.route('/profile/<username>')
    def profile(username):
        user = User.query.filter_by(username=username).first_or_404()
        user_recipes = Recipe.query.options(
            selectinload(Recipe.reviews),
            selectinload(Recipe.favorites)
        ).filter_by(user_id=user.id).order_by(Recipe.created_at.desc()).all()

        favorites = []
        if current_user.is_authenticated and current_user.id == user.id:
            favorites = [fav.recipe for fav in user.favorites if fav.recipe]

        total_views = sum(r.views_count for r in user_recipes)
        ratings = [r.average_rating for r in user_recipes if r.average_rating > 0]
        avg_user_rating = round(sum(ratings) / len(ratings), 1) if ratings else 0.0

        return render_template(
            'profile.html',
            profile_user=user,
            recipes=user_recipes,
            favorites=favorites,
            total_views=total_views,
            avg_rating=avg_user_rating
        )

    @app.route('/profile/edit', methods=['POST'])
    @login_required
    def edit_profile():
        bio = request.form.get('bio', '').strip()
        telegram_chat_id = request.form.get('telegram_chat_id', '').strip()
        current_user.bio = bio
        if telegram_chat_id is not None:
            current_user.telegram_chat_id = telegram_chat_id

        if 'avatar' in request.files:
            file = request.files['avatar']
            if file and file.filename != '' and allowed_file(file.filename):
                current_user.avatar = save_optimized_image(file)

        db.session.commit()
        flash('Профиль успешно обновлен!', 'success')
        return redirect(url_for('profile', username=current_user.username))

    @app.route('/shopping-list')
    def shopping_list():
        return render_template('shopping_list.html')

    @app.route('/my_recipes')
    @login_required
    def my_recipes():
        return redirect(url_for('profile', username=current_user.username))

    # ==========================================================================
    # INTEGRATION 1: GOOGLE OAUTH 2.0 AUTHENTICATION
    # ==========================================================================
    @app.route('/auth/google')
    def google_login():
        auth_url, is_live = GoogleOAuthIntegration.get_authorization_url()
        return redirect(auth_url)

    @app.route('/auth/google/simulator', methods=['GET', 'POST'])
    def google_oauth_simulator():
        """Educational Google OAuth 2.0 Consent Screen Simulator for local defense without cloud keys."""
        state = request.args.get('state') or session.get('oauth_state') or secrets.token_urlsafe(16)
        session['oauth_state'] = state

        if request.method == 'POST':
            email = request.form.get('email', 'alexey.gourmet@gmail.com').strip().lower()
            full_name = request.form.get('full_name', 'Алексей Гурманов').strip()
            username_slug = email.split('@')[0].replace('.', '_')
            session['sandbox_google_profile'] = {
                'sub': f"google-oauth2|{abs(hash(email))}",
                'email': email,
                'name': username_slug,
                'full_name': full_name,
                'picture': f"https://ui-avatars.com/api/?name={full_name}&background=4285F4&color=fff&size=128&bold=true"
            }
            sandbox_code = f"sandbox_code_{secrets.token_hex(8)}"
            return redirect(url_for('google_callback', code=sandbox_code, state=state))

        return render_template(
            'google_oauth_simulator.html',
            demo_accounts=GoogleOAuthIntegration.DEMO_ACCOUNTS,
            state=state
        )

    @app.route('/auth/google/callback')
    def google_callback():
        code = request.args.get('code', '')
        if not code:
            flash('Авторизация через Google была отменена.', 'warning')
            return redirect(url_for('login'))

        try:
            profile = GoogleOAuthIntegration.exchange_code_for_user(code)
            user = GoogleOAuthIntegration.get_or_create_oauth_user(profile)
            login_user(user, remember=True)
            flash(f'Вы успешно вошли через Google аккаунт ({user.email})!', 'success')
            return redirect(url_for('index'))
        except Exception as exc:
            flash(f'Ошибка авторизации через Google OAuth: {str(exc)}', 'error')
            return redirect(url_for('login'))

    # ==========================================================================
    # INTEGRATION 2: TELEGRAM BOT API (@RecipeCollectionEduBot)
    # ==========================================================================
    @app.route('/integrations/telegram/send-recipe/<int:recipe_id>', methods=['POST'])
    def telegram_send_recipe(recipe_id):
        recipe = Recipe.query.get_or_404(recipe_id)
        chat_id = request.form.get('chat_id') or (
            current_user.telegram_chat_id if current_user.is_authenticated and current_user.telegram_chat_id else None
        )
        resp_data, status = TelegramBotIntegration.send_recipe_card(recipe, chat_id=chat_id)
        msg = f'Карточка рецепта «{recipe.title}» отправлена в Telegram-бот!'

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
            return jsonify({'status': 'success', 'delivery': status, 'message': msg, 'telegram_response': resp_data})

        flash(msg, 'success')
        return redirect(url_for('recipe_detail', recipe_id=recipe.id))

    @app.route('/integrations/telegram/send-shopping-list', methods=['POST'])
    def telegram_send_shopping_list():
        data = request.get_json(silent=True) or {}
        items = data.get('items') or []
        chat_id = data.get('chat_id') or (
            current_user.telegram_chat_id if current_user.is_authenticated and current_user.telegram_chat_id else None
        )
        username = current_user.username if current_user.is_authenticated else 'Кулинар'
        resp_data, status = TelegramBotIntegration.send_shopping_list(items, chat_id=chat_id, username=username)
        return jsonify({
            'status': 'success',
            'delivery': status,
            'message': 'Список покупок успешно отправлен в ваш Telegram!',
            'telegram_response': resp_data
        })

    @app.route('/integrations/telegram/command', methods=['POST'])
    def telegram_bot_command():
        data = request.get_json(silent=True) or request.form
        command_text = data.get('command', '/start')
        chat_id = data.get('chat_id') or app.config['TELEGRAM_DEFAULT_CHAT_ID']
        resp_data, status = TelegramBotIntegration.handle_bot_command(chat_id, command_text)
        return jsonify({
            'status': 'success',
            'delivery': status,
            'bot_reply': resp_data.get('result', {}).get('text', ''),
            'raw_payload': resp_data
        })

    @app.route('/api/integrations/telegram/webhook', methods=['POST'])
    def telegram_webhook():
        """Official Telegram Bot Webhook receiver."""
        update = request.get_json(silent=True) or {}
        message = update.get('message', {})
        chat_id = message.get('chat', {}).get('id', app.config['TELEGRAM_DEFAULT_CHAT_ID'])
        text = message.get('text', '/start')
        resp_data, _ = TelegramBotIntegration.handle_bot_command(chat_id, text)
        return jsonify({'ok': True, 'handled': True, 'response': resp_data})

    # ==========================================================================
    # INTEGRATION 3: PAYMENT GATEWAY (YooKassa / CloudPay Sandbox)
    # ==========================================================================
    @app.route('/payment/create', methods=['POST'])
    def create_payment():
        payment_type = request.form.get('payment_type', 'donation')
        amount = request.form.get('amount', type=int) or 150
        recipe_id = request.form.get('recipe_id', type=int)
        recipient_id = request.form.get('recipient_id', type=int)
        payment_method = request.form.get('payment_method', 'card')
        comment = request.form.get('comment', '').strip()

        if payment_type == 'pro_subscription':
            amount = app.config.get('PRO_SUBSCRIPTION_PRICE', 299)
            comment = 'Подписка Culinary PRO (Безлимитный доступ и PRO-статус)'

        user_id = current_user.id if current_user.is_authenticated else None
        tx = PaymentGatewayIntegration.create_transaction(
            amount=amount,
            payment_type=payment_type,
            user_id=user_id,
            recipient_id=recipient_id,
            recipe_id=recipe_id,
            payment_method=payment_method,
            comment=comment
        )
        return redirect(url_for('payment_checkout', transaction_uuid=tx.transaction_uuid))

    @app.route('/payment/checkout/<transaction_uuid>')
    def payment_checkout(transaction_uuid):
        tx = PaymentTransaction.query.filter_by(transaction_uuid=transaction_uuid).first_or_404()
        signature = PaymentGatewayIntegration.generate_signature(tx.transaction_uuid, tx.amount)
        return render_template('payment_checkout.html', tx=tx, signature=signature)

    @app.route('/payment/process/<transaction_uuid>', methods=['POST'])
    def payment_process(transaction_uuid):
        tx = PaymentTransaction.query.filter_by(transaction_uuid=transaction_uuid).first_or_404()
        payment_method = request.form.get('payment_method', tx.payment_method)
        PaymentGatewayIntegration.complete_transaction(tx, payment_method=payment_method)

        # Send automatic notification to Telegram Bot log
        if tx.payment_type == 'pro_subscription':
            TelegramBotIntegration.send_message(
                app.config['TELEGRAM_DEFAULT_CHAT_ID'],
                f"💎 *Активирована подписка Culinary PRO!*\nТранзакция: `{tx.transaction_uuid}`\nСумма: *{tx.amount} ₽*"
            )
            flash('Поздравляем! Статус Culinary PRO успешно активирован!', 'success')
        else:
            recipient_name = tx.recipient.username if tx.recipient else 'Автору'
            TelegramBotIntegration.send_message(
                app.config['TELEGRAM_DEFAULT_CHAT_ID'],
                f"☕ *Новый донат автору @{recipient_name}!*\nСумма: *{tx.amount} ₽*\nКомментарий: _{tx.comment or 'Спасибо за рецепт!'}_"
            )
            flash(f'Оплата {tx.amount} ₽ прошла успешно! Спасибо за поддержку автора.', 'success')

        return redirect(url_for('payment_receipt', transaction_uuid=tx.transaction_uuid))

    @app.route('/payment/receipt/<transaction_uuid>')
    def payment_receipt(transaction_uuid):
        tx = PaymentTransaction.query.filter_by(transaction_uuid=transaction_uuid).first_or_404()
        return render_template('payment_receipt.html', tx=tx)

    @app.route('/api/integrations/payment/webhook', methods=['POST'])
    def payment_webhook():
        """Webhook endpoint for YooKassa / CloudPay asynchronous notifications."""
        payload = request.get_json(silent=True) or {}
        tx_uuid = payload.get('transaction_uuid')
        signature = payload.get('signature', '')
        tx = PaymentTransaction.query.filter_by(transaction_uuid=tx_uuid).first_or_404()

        expected_sig = PaymentGatewayIntegration.generate_signature(tx.transaction_uuid, tx.amount)
        if not hmac.compare_digest(signature, expected_sig):
            return jsonify({'status': 'error', 'message': 'Invalid HMAC signature'}), 400

        PaymentGatewayIntegration.complete_transaction(tx)
        return jsonify({'status': 'succeeded', 'transaction': tx.to_dict()})

    # ==========================================================================
    # UNIFIED INTEGRATIONS & PERFORMANCE HUB PAGE (/integrations)
    # ==========================================================================
    @app.route('/integrations')
    def integrations_hub():
        telegram_logs = TelegramLog.query.order_by(TelegramLog.created_at.desc()).limit(12).all()
        recent_payments = PaymentTransaction.query.order_by(PaymentTransaction.created_at.desc()).limit(8).all()
        perf_summary = perf_monitor.summary()
        cache_stats = app_cache.stats()
        sample_recipe = Recipe.query.first()

        return render_template(
            'integrations_hub.html',
            telegram_logs=list(reversed(telegram_logs)),
            recent_payments=recent_payments,
            perf_summary=perf_summary,
            cache_stats=cache_stats,
            sample_recipe=sample_recipe,
            google_live=GoogleOAuthIntegration.is_live_configured(),
            telegram_live=TelegramBotIntegration.is_live_configured()
        )

    # ==================== ADMIN PANEL ====================
    @app.route('/admin')
    @login_required
    @admin_required
    def admin_dashboard():
        total_users = User.query.count()
        total_recipes = Recipe.query.count()
        total_reviews = Review.query.count()
        total_favorites = Favorite.query.count()
        total_payments = PaymentTransaction.query.filter_by(status='succeeded').count()

        recent_recipes = Recipe.query.options(joinedload(Recipe.author)).order_by(Recipe.created_at.desc()).limit(5).all()
        recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()

        return render_template(
            'admin_dashboard.html',
            total_users=total_users,
            total_recipes=total_recipes,
            total_reviews=total_reviews,
            total_favorites=total_favorites,
            total_payments=total_payments,
            recent_recipes=recent_recipes,
            recent_users=recent_users,
            perf_summary=perf_monitor.summary(),
            cache_stats=app_cache.stats()
        )

    @app.route('/admin/recipes')
    @login_required
    @admin_required
    def admin_recipes():
        recipes = Recipe.query.options(joinedload(Recipe.author)).order_by(Recipe.created_at.desc()).all()
        return render_template('admin_recipes.html', recipes=recipes)

    @app.route('/admin/users')
    @login_required
    @admin_required
    def admin_users():
        users = User.query.order_by(User.created_at.desc()).all()
        return render_template('admin_users.html', users=users)

    @app.route('/admin/reviews')
    @login_required
    @admin_required
    def admin_reviews():
        reviews = Review.query.options(joinedload(Review.author), joinedload(Review.recipe)).order_by(Review.created_at.desc()).all()
        return render_template('admin_reviews.html', reviews=reviews)

    @app.route('/admin/user/<int:user_id>/toggle-admin', methods=['POST'])
    @login_required
    @admin_required
    def admin_toggle_role(user_id):
        if user_id == current_user.id:
            flash('Вы не можете изменить роль собственного аккаунта!', 'error')
            return redirect(url_for('admin_users'))

        user = User.query.get_or_404(user_id)
        user.is_admin = not user.is_admin
        db.session.commit()
        status_str = 'Администратор' if user.is_admin else 'Пользователь'
        flash(f'Роль пользователя {user.username} изменена на: {status_str}', 'success')
        return redirect(url_for('admin_users'))

    @app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
    @login_required
    @admin_required
    def admin_delete_user(user_id):
        if user_id == current_user.id:
            flash('Вы не можете удалить свой собственный аккаунт!', 'error')
            return redirect(url_for('admin_users'))

        user = User.query.get_or_404(user_id)
        username = user.username

        for recipe in user.recipes:
            for filename in recipe.get_images():
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                    except OSError:
                        pass

        db.session.delete(user)
        db.session.commit()
        app_cache.invalidate_prefix('')
        flash(f'Пользователь {username} и все его данные успешно удалены!', 'success')
        return redirect(url_for('admin_users'))

    # ==================== AUTHENTICATION ====================
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for('index'))

        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            email = request.form.get('email', '').strip().lower()
            password = request.form.get('password', '')
            confirm_password = request.form.get('confirm_password', '')

            if not username or not email or not password:
                flash('Пожалуйста, заполните все обязательные поля!', 'error')
                return render_template('register.html')

            if len(password) < 6:
                flash('Пароль должен содержать не менее 6 символов!', 'error')
                return render_template('register.html')

            if password != confirm_password:
                flash('Введенные пароли не совпадают!', 'error')
                return render_template('register.html')

            if User.query.filter_by(username=username).first():
                flash('Пользователь с таким именем уже существует!', 'error')
                return render_template('register.html')

            if User.query.filter_by(email=email).first():
                flash('Пользователь с таким email уже зарегистрирован!', 'error')
                return render_template('register.html')

            user = User(username=username, email=email)
            user.set_password(password)

            if User.query.count() == 0:
                user.is_admin = True

            db.session.add(user)
            db.session.commit()
            app_cache.invalidate_prefix('')

            login_user(user)
            flash('Добро пожаловать в Recipe Collection! Регистрация прошла успешно.', 'success')
            return redirect(url_for('index'))

        return render_template('register.html')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for('index'))

        if request.method == 'POST':
            login_input = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            remember = bool(request.form.get('remember'))

            user = User.query.filter(
                (User.username == login_input) | (User.email == login_input.lower())
            ).first()

            if user and user.check_password(password):
                login_user(user, remember=remember)
                flash(f'С возвращением, {user.username}!', 'success')
                next_page = request.args.get('next')
                return redirect(next_page) if next_page else redirect(url_for('index'))
            else:
                flash('Неверное имя пользователя/email или пароль.', 'error')

        return render_template('login.html')

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        flash('Вы успешно вышли из учетной записи.', 'info')
        return redirect(url_for('index'))

    # ==================== REST API ENDPOINTS ====================
    @app.route('/api/recipes', methods=['GET'])
    def api_recipes():
        page = request.args.get('page', 1, type=int)
        limit = min(request.args.get('limit', 10, type=int), 50)
        search = request.args.get('q', '').strip()
        cuisine = request.args.get('cuisine', '').strip()
        category = request.args.get('category', '').strip()

        query = Recipe.query.options(joinedload(Recipe.author), selectinload(Recipe.reviews), selectinload(Recipe.favorites))
        if search:
            query = query.filter(Recipe.title.ilike(f"%{search}%"))
        if cuisine:
            query = query.filter(Recipe.cuisine == cuisine)
        if category and category != 'Все':
            query = query.filter(Recipe.category == category)

        pagination = query.order_by(Recipe.created_at.desc()).paginate(page=page, per_page=limit, error_out=False)

        return jsonify({
            'total': pagination.total,
            'pages': pagination.pages,
            'current_page': page,
            'recipes': [r.to_dict() for r in pagination.items]
        })

    @app.route('/api/recipes/<int:recipe_id>', methods=['GET'])
    def api_recipe_detail(recipe_id):
        recipe = Recipe.query.options(
            joinedload(Recipe.author),
            selectinload(Recipe.reviews).joinedload(Review.author)
        ).get_or_404(recipe_id)
        data = recipe.to_dict()
        data['parsed_ingredients'] = recipe.parsed_ingredients()
        data['parsed_instructions'] = recipe.parsed_instructions()
        data['reviews'] = [rev.to_dict() for rev in recipe.reviews]
        return jsonify(data)

    @app.route('/api/stats', methods=['GET'])
    def api_stats():
        counts = get_cached_global_counts()
        return jsonify({
            'users_count': counts['users_count'],
            'recipes_count': counts['recipes_count'],
            'reviews_count': counts['reviews_count'],
            'cuisines': app.config['CUISINES'],
            'categories': app.config['CATEGORIES'],
            'performance': perf_monitor.summary(),
            'cache': app_cache.stats()
        })

    @app.route('/api/performance', methods=['GET'])
    def api_performance():
        return jsonify({
            'sla_target_ms': 1000,
            'status': 'healthy',
            'performance': perf_monitor.summary(),
            'cache': app_cache.stats()
        })

    # ==================== ERROR HANDLERS ====================
    @app.errorhandler(403)
    def forbidden(e):
        return render_template('errors/403.html'), 403

    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html'), 500

    return app


app = create_app()

if __name__ == '__main__':
    from seed_data import seed_database
    with app.app_context():
        db.create_all()
        if Recipe.query.count() == 0:
            seed_database()
    app.run(host='0.0.0.0', port=5000, debug=True)
